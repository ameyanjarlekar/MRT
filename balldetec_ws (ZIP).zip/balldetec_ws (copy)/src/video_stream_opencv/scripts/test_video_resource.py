#! /usr/bin/env python2
# -*- coding: utf-8 -*-
"""

Copyright (c) 2015 PAL Robotics SL.
Released under the BSD License.

Created on 7/14/15

@author: Sammy Pfeiffer

test_video_resource.py contains
a testing code to see if opencv can open a video stream
useful to debug if video_stream does not work
"""

import cv2
import sys
import os
import numpy as np
import detect_ball
import finalcode
one_rot =10
trace = 0
goku = 0
store = 0
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print "You must give an argument to open a video stream."
        print "  It can be a number as video device, e.g.: 0 would be /dev/video0"
        print "  It can be a url of a stream,        e.g.: rtsp://wowzaec2demo.streamlock.net/vod/mp4:BigBuckBunny_115k.mov"
        print "  It can be a video file,             e.g.: myvideo.mkv"
        exit(0)

    resource = sys.argv[1]
    # If we are given just a number, interpret it as a video device
    if len(resource) < 3:
        resource_name = "/dev/video" + resource
        resource = int(resource)
    else:
        resource_name = resource
    print "Trying to open resource: " + resource_name
    cap = cv2.VideoCapture(resource)
    if not cap.isOpened():
        print "Error opening resource: " + str(resource)
        print "Maybe opencv VideoCapture can't open it"
        exit(0)

    print "Correctly opened resource, starting to show feed."
    rval, frame = cap.read()
    t = 0
    while rval:
        cv2.imshow("Stream: " + resource_name, frame)
        rval, frame = cap.read()
        (rval,frame) = cap.read()
        image, frame = detect_ball.detect_ball(frame)
                
        #image, frame = detect_ball.detect_ball(frame)
        if (np.any(frame)):
            # cv2.imwrite("/home/ameya/Desktop/MRT/current/" + str(i) + ".jpg",frame)

            multWindow = detect_ball.getMultiWindow(image, frame)
            path = '/home/ameya/Desktop/MRT/current/' + str(t)
            if not os.path.exists(path):
                os.makedirs(path)
            for j in range(len(multWindow)):
                cv2.imwrite(path + '/' + str(j) + ".jpg",multWindow[j])
                #cv2.imwrite("/home/ameya/Desktop/MRT/current/" + str(t) + ".jpg",image)
                #data.append(image)
                #np.save('/home/ameya/Desktop/MRT/current/outputnoball' + str(t) +'.npy', detect_ball.getMultiWindowArray(image, frame))
            rectangle = detect_ball.getMultiWindowArray(image, frame)
            goku =  trace          
            trace = max(trace,finalcode.testvalue(rectangle))
            if trace>goku:
                store = t
            print(t)
            t = t+1
            if (t == one_rot): # completed one round
                #np.save('/home/ameya/Desktop/MRT/current/outputnoball' + str(t) +'.npy', detect_ball.getMultiWindowArray(image, frame))
                # call supervised with numpy array and publish result back
                break
                break

            #image = detect_ball.getWindow(image, frame)
            #multWindow = detect_ball.getWindow(image, frame)
            # path = '/home/ameya/Desktop/MRT/current/' + str(rval)
            # if not os.path.exists(path):
            #     os.makedirs(path)
            # #for j in range(len(multWindow)):
            #     cv2.imwrite(path + '/' + str(1) + ".jpg",image)

        key = cv2.waitKey(20)
        # print "key pressed: " + str(key)
        # exit on ESC, you may want to uncomment the print to know which key is ESC for you
        if key == 27 or key == 1048603:
            break
    print(store)
    cv2.destroyWindow("preview")

